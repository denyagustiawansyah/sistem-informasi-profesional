package com.example.deni;

public class Capstone {


    private String mNewsTitle;
    public Capstone(String NewsTitle) {
        mNewsTitle = NewsTitle;
    }
    public String getNewsTitle() {
        return mNewsTitle;
    }
}