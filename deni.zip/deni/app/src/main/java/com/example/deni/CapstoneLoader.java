package com.example.deni;

import android.content.AsyncTaskLoader;
import android.content.Context;
import java.util.List;

public class CapstoneLoader extends AsyncTaskLoader<List<Capstone>> {

    private static final String LOG_TAG = CapstoneLoader.class.getName();
    private String mUrl;
    public CapstoneLoader(Context context, String url) {
        super(context);
        mUrl = url;
    }

    @Override
    protected void onStartLoading() {
        forceLoad();
    }

    @Override
    public List<Capstone> loadInBackground() {
        if (mUrl == null) {
            return null;
        }

        List<Capstone> capstones = QueryUtils.fetchCapstoneData(mUrl);
        return capstones;
    }
}