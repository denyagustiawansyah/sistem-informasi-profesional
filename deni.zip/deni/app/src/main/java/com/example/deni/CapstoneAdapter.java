package com.example.deni;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
//import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import java.text.DecimalFormat;
import java.util.List;


public class CapstoneAdapter extends ArrayAdapter<Capstone> {
    private static final String LOCATION_SEPARATOR = " of ";

    public CapstoneAdapter(Context context, List<Capstone> capstones) {
        super(context, 0, capstones);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.capstone_list_item, parent, false);
        }
        Capstone currentCapstone = getItem(position);
        String originalLocation = currentCapstone.getNewsTitle();
        String primaryLocation;
        primaryLocation = originalLocation;
        TextView primaryLocationView = (TextView) listItemView.findViewById(R.id.news_title);
        primaryLocationView.setText(primaryLocation);
        return listItemView;
    }
}
